<!DOCTYPE html>
<html>
<head>
	<title>Meemure</title>
</head>
<link rel="stylesheet" type="text/css" href="./css/style.css">
<body>
 <header>
 	<img class="headerImage" src="./img/3.jpg" />
 </header>

 <div class="navigation">
 		<ul>
 			<li><a href="">Home</a></li>
 			<li><a href="">About Meemure</a></li>
 			<li><a href="">Contact Us</a></li>
 		</ul>
 </div>

 <div class="mainContent">
 	<div class="tArea">
 		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
 		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
 		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
 		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
 		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
 		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
 	</div>
 </div>

</body>
</html>